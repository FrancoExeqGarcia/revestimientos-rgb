import { useState } from "react";
import "./FlooringSections.css";
import { FlooringGrid } from "./FlooringGrid";
import { FlooringModal } from "./FlooringModal";

export function FlooringSections() {
  const [selectedFloor, setSelectedFloor] = useState<string | null>(null);
  const [bgImage, setBgImage] = useState<string | null>(null);

  return (
    <section id="flooring">
    <div
      className="flooring-sections"
      style={{
        backgroundImage: bgImage ? `url(${bgImage})` : "none",
        backgroundSize: "cover",
        backgroundPosition: "center",
      }}
    >
      <h2 className="section-title">Explora Nuestras Opciones de Pisos</h2>
      <FlooringGrid setSelectedFloor={setSelectedFloor} setBgImage={setBgImage} />
      {selectedFloor && (
        <FlooringModal
          floor={selectedFloor}
          onClose={() => setSelectedFloor(null)}
        />
      )}
    </div>
    </section>
  );
}
